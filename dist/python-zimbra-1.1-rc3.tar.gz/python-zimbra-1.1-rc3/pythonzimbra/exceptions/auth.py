""" Authentication exceptions """


class AuthenticationFailed(BaseException):

    """ Authentication failure
    """

    pass
